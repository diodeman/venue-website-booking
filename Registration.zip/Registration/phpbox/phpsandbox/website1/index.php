<?php require_once 'inc/header.php'; ?>
	<h1>Home</h1>
<?php require_once 'inc/footer.php'; ?>
	