

<!DOCTYPE html>
<html>
<head>
	<title>Venue Booking Website</title>
	<style>
	body{
			background: url('bg.jpg') no-repeat top center;
  			background-size: cover;
  			height: 100vh;
			font-size: 100%;
	}	
	table,th,td{
		border: 1px solid black;
		width: 1100px;
		background-color: green;
	}

	</style>
</head>
<body>
	<center><h1>Retrevieng Data</h1><br>
	<h2>View Booking Request and Accept</h2><br>

	<div class="container">
		<form action="" method="POST">
			<table>
				<tr>
					<th> UserName </th>
					<th> VenueName </th>
					<th> Date </th>
					<th> Email </th>
					<th> Status</th>
					<th> Activate </th>
				</tr>
				
		</form>
		
	</div>
</body>
</html>